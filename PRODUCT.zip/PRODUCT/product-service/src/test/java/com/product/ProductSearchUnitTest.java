package com.product;

import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(classes =ProductsearchApplication.class)
class ProductSearchUnitTest {
	
}
