package com.cts;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryserviceimplTest {
	
}
